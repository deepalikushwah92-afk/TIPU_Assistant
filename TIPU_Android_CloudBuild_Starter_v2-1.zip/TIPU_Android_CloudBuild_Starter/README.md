# TIPU Android Starter

This is a starter project, not a completed assistant. It currently contains a simple Compose home screen and microphone permission prompt only. Wake-word detection, speaker verification, background listening, calls, and advanced security are not implemented yet.

## Build from GitHub Actions
Upload the *contents* of this folder to the root of your GitHub repository (not the ZIP file itself). The `.github` folder may be hidden by Android file managers; enable show hidden files if needed. After uploading and committing, open the repository Actions tab and run 'Build TIPU APK'. Download the `TIPU-debug-APK` artifact after the workflow succeeds.
