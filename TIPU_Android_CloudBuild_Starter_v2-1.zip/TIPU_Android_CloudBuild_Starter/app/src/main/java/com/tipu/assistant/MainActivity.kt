package com.tipu.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TipuHome() }
    }
}

@Composable
private fun TipuHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var micGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED)
    }
    var status by remember { mutableStateOf("Owner Voice Mode तैयार किया जाएगा") }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        micGranted = granted
        status = if (granted) "माइक्रोफोन अनुमति मिली" else "माइक्रोफोन अनुमति नहीं मिली"
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF55C8FF), background = Color(0xFF07111F),
        surface = Color(0xFF101F32)
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF07111F), Color(0xFF102B46)))
        ), contentAlignment = Alignment.Center) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text("TIPU", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Text("Your Personal Smart AI Assistant", color = Color(0xFFB8D8EE))
                Box(Modifier.size(150.dp).background(Color(0xFF123B5A), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text("T", color = Color(0xFF70D5FF), fontSize = 64.sp, fontWeight = FontWeight.Bold)
                }
                Text("नमस्ते! मैं TIPU हूँ।", color = Color.White, fontSize = 22.sp)
                Text("स्थिति: $status", color = Color(0xFFB8D8EE))
                Button(onClick = {
                    if (!micGranted) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    else status = "माइक्रोफोन अनुमति उपलब्ध है — Wake Word अभी जोड़ा जाना बाकी है"
                }) { Text(if (micGranted) "माइक्रोफोन अनुमति जाँचें" else "माइक्रोफोन अनुमति दें") }
                Text("सुरक्षा: Owner Only Voice Mode नियोजित\nअभी कोई रिकॉर्डिंग या कॉल नहीं होती।",
                    color = Color(0xFF9FB6C9), fontSize = 13.sp)
            }
        }
    }
}
