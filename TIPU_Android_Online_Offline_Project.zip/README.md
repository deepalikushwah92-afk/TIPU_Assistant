# TIPU – My Personal AI Voice Assistant

This is an Android source project, not a prebuilt APK. It includes Hindi speech UI, an animated glowing orb, basic offline commands, text-to-speech, and an optional HTTPS AI backend connector.

## Build the APK with GitHub Actions
1. Upload all files and folders from this project to the root of your GitHub repository.
2. Open the repository's Actions tab.
3. Select **Build TIPU APK** and tap **Run workflow** (or push to main).
4. Open the completed run and download the `TIPU-debug-apk` artifact.

## Included now
- Hindi speech recognition through Android's speech service. Offline recognition depends on whether an offline Hindi speech pack is installed on the phone and supported by its recognition provider.
- Spoken replies using Android TextToSpeech; Hindi voice availability depends on installed TTS voices.
- Manual microphone start/stop.
- Basic commands: open WhatsApp, Instagram, YouTube, Maps, open alarms, tell time.
- Optional online AI request to a user-hosted HTTPS endpoint.

## Online AI backend
The app intentionally does not contain an API key. In the app, open **AI सर्वर सेटिंग** and enter an HTTPS endpoint that accepts:
`POST {"message":"...","language":"hi-IN"}`
and returns:
`{"reply":"..."}`

Host a backend that securely calls your chosen AI provider. Keep provider keys on the server, never inside the APK.

## Not included yet
Wake-word always-on detection, background microphone service, voice biometrics, fingerprint/PIN lock, trusted-device approval, incoming WhatsApp/Instagram call controls, direct DM sending, reminders database, and a fully local conversational language model. These require separate implementation, Android permission/testing work, or official service support.

## Notes
- `targetSdk 35`, `minSdk 26`.
- This project has not been built or tested on a physical phone in this environment.
- Grant permissions only when the feature and purpose are clear.
