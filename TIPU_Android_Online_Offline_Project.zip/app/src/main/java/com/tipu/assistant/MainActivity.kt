package com.tipu.assistant

import android.Manifest
import android.app.Activity
import android.app.AlarmClock
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var orb: OrbView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var online = false
    private val prefs by lazy { getSharedPreferences("tipu", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        }
        updateMode()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(7, 12, 29))
        }
        val title = TextView(this).apply {
            text = "TIPU"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            letterSpacing = .22f
        }
        val subtitle = TextView(this).apply {
            text = "MY PERSONAL AI ASSISTANT"; textSize = 11f
            setTextColor(Color.rgb(143, 190, 255)); gravity = Gravity.CENTER
        }
        orb = OrbView(this)
        status = TextView(this).apply {
            text = "तैयार हूँ"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        transcript = TextView(this).apply {
            text = "बोलने के लिए माइक्रोफोन दबाएँ"; textSize = 15f
            setTextColor(Color.rgb(195, 211, 235)); gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
        }
        val mic = Button(this).apply {
            text = "🎙 बोलें"; textSize = 17f
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        val mode = Switch(this).apply {
            text = "Online AI मोड"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, checked ->
                online = checked; prefs.edit().putBoolean("online", checked).apply(); updateMode()
            }
        }
        mode.isChecked = prefs.getBoolean("online", false)
        val hint = TextView(this).apply {
            text = "ऑफलाइन: बेसिक कमांड\nऑनलाइन: आपके AI सर्वर से बातचीत"
            textSize = 12f; setTextColor(Color.rgb(150, 169, 198)); gravity = Gravity.CENTER
            setPadding(8, 16, 8, 10)
        }
        val settings = Button(this).apply {
            text = "AI सर्वर सेटिंग"
            setOnClickListener { showServerSettings() }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 48))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 24))
        root.addView(orb, LinearLayout.LayoutParams(260, 260))
        root.addView(status, LinearLayout.LayoutParams(-1, 42))
        root.addView(transcript, LinearLayout.LayoutParams(-1, 76))
        root.addView(mic, LinearLayout.LayoutParams(-1, 54))
        root.addView(mode, LinearLayout.LayoutParams(-2, 48))
        root.addView(hint, LinearLayout.LayoutParams(-1, 64))
        root.addView(settings, LinearLayout.LayoutParams(-1, 48))
        setContentView(root)
    }

    private fun updateMode() { status.text = if (online) "Online मोड चुना गया" else "Offline मोड" }

    private fun showServerSettings() {
        val input = EditText(this).apply {
            hint = "https://your-server.example/chat"
            setText(prefs.getString("endpoint", "")); textSize = 14f
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("AI सर्वर URL")
            .setMessage("अपने सुरक्षित AI backend का HTTPS URL डालें। API key ऐप में न रखें।")
            .setView(input).setNegativeButton("रद्द", null)
            .setPositiveButton("सेव") { _, _ ->
                prefs.edit().putString("endpoint", input.text.toString().trim()).apply()
                speak("सेटिंग सेव हो गई")
            }.show()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            transcript.text = "इस फोन में Speech Recognition उपलब्ध नहीं है"; return
        }
        listening = true; orb.state = 1; status.text = "सुन रहा हूँ..."; transcript.text = "अब बोलिए"
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { orb.level = rmsdB }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "समझ रहा हूँ..." }
            override fun onError(error: Int) {
                listening = false; orb.state = 0; status.text = "फिर से कोशिश करें"
            }
            override fun onResults(results: Bundle?) {
                listening = false; orb.state = 2
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                transcript.text = words.ifBlank { "आवाज़ समझ नहीं आई" }
                handleCommand(words)
                orb.postDelayed({ orb.state = 0 }, 1500)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !online)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun stopListening() {
        listening = false; recognizer?.cancel(); orb.state = 0; status.text = "Listening बंद"
    }

    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        when {
            q.contains("व्हाट्सएप") || q.contains("whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            q.contains("इंस्टाग्राम") || q.contains("instagram") -> openApp("com.instagram.android", "Instagram")
            q.contains("यूट्यूब") || q.contains("youtube") -> openApp("com.google.android.youtube", "YouTube")
            q.contains("मैप") || q.contains("maps") -> openApp("com.google.android.apps.maps", "Maps")
            q.contains("अलार्म") || q.contains("alarm") -> try {
                startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS)); speak("अलार्म खोल रही हूँ")
            } catch (_: Exception) { speak("अलार्म ऐप उपलब्ध नहीं है") }
            q.contains("समय") || q.contains("time") -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale("hi", "IN")).format(java.util.Date())
                speak("अभी समय है $now")
            }
            else -> if (online) askOnline(raw)
                else speak("यह कमांड अभी ऑफलाइन उपलब्ध नहीं है। Online मोड चालू करके पूछें।")
        }
    }

    private fun openApp(pkg: String, name: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) { startActivity(launch); speak("$name खोल रही हूँ") }
        else speak("$name इंस्टॉल नहीं है")
    }

    // Backend contract: POST {"message":"...","language":"hi-IN"} -> {"reply":"..."}
    // Keep provider API keys on the backend, never inside the APK.
    private fun askOnline(message: String) {
        val endpoint = prefs.getString("endpoint", "").orEmpty()
        if (!endpoint.startsWith("https://")) {
            speak("Online AI के लिए पहले AI सर्वर URL सेटिंग में डालें"); return
        }
        status.text = "Online AI से जवाब ला रही हूँ..."
        thread {
            var answer: String
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 12000; readTimeout = 15000
                    doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = org.json.JSONObject().put("message", message).put("language", "hi-IN").toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                answer = org.json.JSONObject(response).optString("reply", "")
                conn.disconnect()
            } catch (_: Exception) { answer = "Online AI सर्वर से कनेक्शन नहीं हो पाया।" }
            runOnUiThread {
                status.text = "जवाब मिल गया"
                if (answer.isBlank()) answer = "सर्वर से जवाब नहीं मिला"
                transcript.text = answer; speak(answer)
            }
        }
    }

    private fun speak(text: String) {
        status.text = "TIPU बोल रही है..."
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tipu_reply")
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }
    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    inner class OrbView(context: android.content.Context) : View(context) {
        var state = 0
            set(value) { field = value; invalidate() }
        var level = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        private val ticker = object : Runnable {
            override fun run() { phase += .035f; invalidate(); postDelayed(this, 40) }
        }
        init { post(ticker) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val pulse = if (state == 1) 1f + kotlin.math.sin(phase * 4) * .06f else 1f + kotlin.math.sin(phase) * .018f
            val radius = width.coerceAtMost(height) * .30f * pulse
            glow.color = Color.rgb(0, 170, 255); glow.alpha = 45
            glow.maskFilter = BlurMaskFilter(radius * .65f, BlurMaskFilter.Blur.NORMAL)
            canvas.drawCircle(cx, cy, radius * 1.25f, glow); glow.maskFilter = null
            paint.shader = RadialGradient(cx-radius*.25f, cy-radius*.3f, radius*1.5f,
                intArrayOf(Color.rgb(160,245,255), Color.rgb(25,135,255), Color.rgb(30,35,120), Color.TRANSPARENT),
                floatArrayOf(0f,.38f,.78f,1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, radius, paint); paint.shader = null
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f
            paint.color = if (state == 1) Color.CYAN else Color.rgb(95,170,255)
            canvas.drawCircle(cx, cy, radius * (1.25f + if (state == 1) .08f else 0f), paint)
            paint.style = Paint.Style.FILL
        }
    }
}
